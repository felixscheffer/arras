import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.BrowserType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Main {

    public static void main(String[] args) {
        new Main().runTest();
    }

    private WebDriver driver;

    public Main() {
        this.driver = getWebDriver();
    }

    public void runTest() {

        // open the online demo - may take a moment
        this.driver.get("http://arras-components.herokuapp.com/remotesubmitdemo");

        // ensure that the page loaded properly
        waitUntil(pageHasLoaded());

        By selector = By.cssSelector("#invisibleExampleTextfield");

        WebElement element = this.driver.findElement(selector);

        // focus the element
        element.click();

        // ensure that the right element is focused before calling sendKeys()
        waitUntil(focusOnElementLocated(selector));

        String text = "Hello World";

        element.clear();
        element.sendKeys(text);

        try {
            Thread.sleep(30000);
        }
        catch (InterruptedException e) {}

        this.driver.quit();

    }

    private static WebDriver getWebDriver() {

        String remoteUrl = System.getProperty("remote");

        if (remoteUrl != null) {

            DesiredCapabilities capabilities = new DesiredCapabilities(BrowserType.CHROME, "39", Platform.ANY);
            capabilities.setCapability("name", "chrome sendKeys test");

            try {
                return new RemoteWebDriver(new URL(remoteUrl), capabilities);
            }
            catch (MalformedURLException e) {
                throw new RuntimeException(e);
            }
        }

        return new ChromeDriver();
    }

    private <T> void waitUntil(ExpectedCondition<T> condition) {
        int timeOutInSeconds = 30;
        int sleepInMillis = 200;
        new WebDriverWait(this.driver, timeOutInSeconds, sleepInMillis).until(condition);
    }

    public static ExpectedCondition<WebElement> focusOnElementLocated(final By locator) {

        return new ExpectedCondition<WebElement>() {

            public WebElement apply(WebDriver driver) {

                WebElement focusedElement = driver.switchTo().activeElement();

                return focusedElement.equals(findElement(locator, driver)) ? focusedElement : null;
            }
        };
    }

    // Apache Tapestry 5 related...
    public static ExpectedCondition<Boolean> pageHasLoaded() {

        return new ExpectedCondition<Boolean>() {

            public Boolean apply(WebDriver driver) {

                WebElement body;
                try {
                    body = findElement(By.cssSelector("body"), driver);
                }
                catch (NoSuchElementException e) {

                    // In a limited number of cases, a "page" is an container error page or raw HTML content
                    // that does not include the body element and data-page-initialized element. In those cases,
                    // there will never be page initialization in the Tapestry sense and we return immediately.

                    return true;
                }

                String initialized = body.getAttribute("data-page-initialized");

                if (initialized == null || "true".equals(initialized)) {
                    // if the attribute is missing, then this is probably not a tapestry page (see above)
                    return true;
                }

                return false;
            }
        };
    }

    private static WebElement findElement(By by, WebDriver driver) {
        try {
            return driver.findElement(by);
        }
        catch (NoSuchElementException e) {
            throw e;
        }
        catch (WebDriverException e) {
            throw e;
        }
    }
}
